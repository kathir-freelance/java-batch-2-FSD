class TestFor{

	public static void main(String ar[]){
	
		int i=1;
		for(;i<3;)
		{
		System.out.println("Hi");
		i++;
		}
	}
}