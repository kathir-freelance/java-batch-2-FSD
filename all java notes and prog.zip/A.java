import java.io.*;
class A
{

public static void main(String arg[])throws IOException{
		try{
			int c=0;
			FileReader fr=new FileReader("a.txt");
			c=fr.read();
			System.out.println(c);
		}
		finally{}
}

}