
public class VolatileEg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThread m=new MyThread();
		m.start();
		MyThread m1=new MyThread();
		m1.start();
	}

}
class MyThread extends Thread {

	  private int value = 1;

	  @Override
	  public void run() {
		  String name=Thread.currentThread().getName();
	    System.out.println(name+" before change "+value);

	    try {
	      Thread.sleep(5000);
	    } catch (InterruptedException e) {
	    }
	 //   if(name.equals("Thread-1")) {
	    	changeValue();
	    	
	   // }
	    // If another thread called changeValue()
	    // in the meantime the next print instruction is
	    // guaranteed to write "2"
	   
	    System.out.println(name+" after change "+value);

	  }

	  public void changeValue() {
	    ++value;
	  }

	}