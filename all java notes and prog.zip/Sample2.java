//public 
class Sample2
{
	public static void main(String args[])
	{
		int a=5;
		switch(a)
		{
			 
				System.out.println("default");
				break;
			case 1:
				System.out.println("one");
				break;
			case 2:
				System.out.println("one");
				break;
					

		}
		
	}
}

/*constructs
	if
		if(condition)
		{
			true part
		}
	
	if...else

		if(condition)
		{
			true part
		}
		else
		{
			false part			
		}
	
	elseif
	switch

		options- char,int,Enum,String(j7)   ====boolean,float,double ?	
		switch(option)
		{
			case 1:
				break;
			case 2:
				break;
			::
			::
			default:

		}
		

//loops

	while
	do...while
	for	
*/