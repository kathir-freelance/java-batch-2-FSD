//public 
class Sample3
{
	public static void main(String args[])
	{
		int a=11;
		do{
		System.out.println("hello "+a);
		a+=2;
		}while(a<10);
		
	}
}