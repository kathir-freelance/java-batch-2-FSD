//CAVAJ - decompiles the code (bytecode to source code)
//JAVAP- gives over view of java class using bytecode file(.class)
public class Sample
{
	public static void main(String args[])
	{
	int a=0;//local variable must be initialized
	System.out.println("a value is "+a);
	}
}

class A{
	public static void main(String args[])
	{
	System.out.println("A");
	}
}

class B{
	public static void main(String args[])
	{
	System.out.println("B");
	}
}