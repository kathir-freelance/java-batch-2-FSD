class A{
}

interface B{
	void run();
}

class Test{
	public static void main(String...ar)
	{
		B obj=null;
		obj=new B(){ 
				public void run(){}
			};
	}
}
