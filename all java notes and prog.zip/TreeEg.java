
import java.util.Set;
import java.util.TreeSet;
class TreeEg{

TreeEg(int h){
}

public static void main(String[] args) {
TreeEg t=new TreeEg(10);
		Set s=new TreeSet();
	s.add(null);
	System.out.println(s);
}
}