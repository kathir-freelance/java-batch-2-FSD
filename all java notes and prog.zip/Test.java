import java.util.*;
import java.io.*;
class TestTypeErasure1{
	public static void main(String ar[]){
		List<String> s=new ArrayList<String>();
		List d=new ArrayList();
		ArrayList r=new ArrayList();
		List t=new LinkedList();
		Map m=new HashMap();
		Console c=System.console();//?
		System.out.println(new String(c.readPassword("password")));
	}
}

class TestTypeErasure2{
	public static void main(String ar[]){
		ArrayList d=new ArrayList();
	}
}