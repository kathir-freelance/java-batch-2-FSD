package com.atos.day2_abstraction;

public interface IContract2 extends IContract{

	public static final int NO_OF_DAYS=10;
	public abstract void trainingSpring();
	//t java() + t jsp()
}

interface I1{
	public void m1();
}
interface I2{
	
	public void m2();
}
interface I3 extends I2
{
	//ref to m2()
	public void m3();
	}
interface I4 extends I1,I3
{
	//ref to m1(), m3() [m2]
	public void m4();
	}

class A implements I4{
	
	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m4() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}

interface Data //extends java.lang.Object
{
	public void display();
}
class C implements Data{
	
	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
}
class B implements Data
{

	@Override
	public void display() {
		//super.display();
	}
	public static void main(String ar[]){
		Data d=null;
		//d=new B();
		//d.display();
		//d.
	}
	
}


interface X{
	
}
interface Y{
	
}

class Alpha{
	
}
class D extends Alpha implements X,Y{
	
}