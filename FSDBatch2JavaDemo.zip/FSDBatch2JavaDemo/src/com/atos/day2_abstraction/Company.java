package com.atos.day2_abstraction;

public class Company {

	public static void main(String[] args) {
		
		IContract i1=new IIHT();
		i1=new NIIT();
		i1.trainingJava();
		i1.trainingJsp();
		if(i1 instanceof IIHT){
		IIHT iObj=(IIHT)i1;
		iObj.internalAudit();
		}
		else{
			System.out.println("pls contact admin");
		}
		System.out.println("contract of IIHT is over");
		i1=new NIIT();
		i1.trainingJava();
		i1.trainingJsp();
		
		IContract2 i2=new NIIT();
		i2.trainingJava();
		i2.trainingJsp();
		i2.trainingSpring();
		
		
	}

}
