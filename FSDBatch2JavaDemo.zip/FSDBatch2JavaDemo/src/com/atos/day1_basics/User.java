package com.atos.day1_basics;

public class User {

	public void login(){
		System.out.println("login in base");
	}
}
