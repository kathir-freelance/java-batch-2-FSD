package com.atos.day1_basics;

public class TestOverride {

	public static void main(String[] args) {

		Human h=new Human();
		h.jump();
		h.walk();
	}

}
