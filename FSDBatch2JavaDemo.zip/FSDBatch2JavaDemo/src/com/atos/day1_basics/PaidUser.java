package com.atos.day1_basics;

public class PaidUser extends User{

	public void login(){
		System.out.println("login in paid user");
	}
	public void offlineDownload(){
		System.out.println("offline download is done");
	}
}

