package com.atos.day1_basics;

public class GuestUser extends User{

	public void login(){
		System.out.println("login for guest user ");
	}
	public void registerAsPaid(){
		System.out.println("subscribed");
	}
}
