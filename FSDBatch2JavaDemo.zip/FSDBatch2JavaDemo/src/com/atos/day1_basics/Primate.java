package com.atos.day1_basics;

public class Primate {

	public void jump()
	{
		System.out.println("jumping....");
	}
	public void walk()
	{
		System.out.println("2legs and 2 hands");
	}

}
