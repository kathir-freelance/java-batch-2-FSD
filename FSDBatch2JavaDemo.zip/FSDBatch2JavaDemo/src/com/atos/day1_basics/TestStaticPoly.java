package com.atos.day1_basics;

public class TestStaticPoly {

	public static void main(String[] args) {
		
		
	}

}

class Student{
	//overloading
	public void write(){
		System.out.println("in write");
	}
	public void write(int pen){
		System.out.println("in write");
	}
	public void write(String note){
		System.out.println("in write");
	}
	public void write(int pen ,String note){
		System.out.println("in write");
		
	}
	
	public void write(String note,int pen){
		System.out.println("in write");
	}
	
	
}