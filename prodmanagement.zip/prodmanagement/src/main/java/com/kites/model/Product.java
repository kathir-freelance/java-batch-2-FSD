package com.kites.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Product {

	private int pid;
	@NotBlank(message="pls enter name")
	@Size(min=3,max=9,message="it should be 3 to 9")
	private String prName;
	@NotNull(message="pls enter qty")
	private Integer qty;
	private Float price;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPrName() {
		return prName;
	}

	public void setPrName(String prName) {
		this.prName = prName;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", prName=" + prName + ", qty=" + qty + ", price=" + price + "]";
	}

	public Product(int pid, String prName, int qty, float price) {
		super();
		this.pid = pid;
		this.prName = prName;
		this.qty = qty;
		this.price = price;
	}
	
	
}
