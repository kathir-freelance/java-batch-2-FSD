package com.kites.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.kites.model.Product;

@Controller
public class ProductController {

	private Map prodList=null;
	
	public ProductController() {
	prodList=new HashMap<>();
	prodList.put(1001,new Product(1001,"toy",7,989));
	prodList.put(1002,new Product(1002,"ac",7,99989));
	prodList.put(1003,new Product(1003,"oven",7,8987));
	}
	
	@RequestMapping("/addProduct")
	public String getAdPage(Model m){
		//create a obj and give to form as req attr
		Product p=new Product();
		m.addAttribute("prod1", p);
		return "add";
	}
	@RequestMapping(value="/prod.do",method=RequestMethod.POST)
	public String processAdd(@Valid @ModelAttribute("prod1") Product prod,BindingResult br,Model m){
		System.out.println(prod);
		
		String path="add";
		if(br.hasErrors()){
			path="add";
		}
		else{
			prod.setPid(1122*2);
		prodList.put(prod.getPid(), prod);
		System.out.println(prodList);
		
		m.addAttribute("stored_prod_id",prod.getPid());
		}
		return path;
	}
	
}
