package com.atos.day2_abstraction;

public class TestInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
