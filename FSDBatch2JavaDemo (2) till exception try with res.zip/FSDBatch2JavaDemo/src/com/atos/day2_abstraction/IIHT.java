package com.atos.day2_abstraction;

public class IIHT implements IContract {

	int balance=0;

	@Override
	public void trainingJava() {
	
		balance=IContract.NO_OF_DAYS-20;
		
		System.out.println("training java over :: days left is "+balance);
	}

	@Override
	public void trainingJsp() {
		
		balance=balance-10;
		System.out.println("training in jsp and servlet done :: days left is "+balance);
		
	}

	public void internalAudit(){
		System.out.println("audit is done");
	}
}
