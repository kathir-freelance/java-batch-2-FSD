package com.atos.day2_abstraction;

public interface IContract {

	public static final int NO_OF_DAYS=31; //can be accessed by ob of subtype or class name of interface
	 void trainingJava();
	 void trainingJsp();

}
