package com.atos.collectiondemo_day3;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {

		Set s=new HashSet<>();//unordered and no dupli
		
		s.add("hi");
		s.add("hi");
		s.add(123);
		s.add(new Float(23.45));
		s.add(null);
		s.add(null);
		System.out.println(s);
		
		s.add(new Admin());
		s.add(new Admin());
		System.out.println(s.size());
		
		s=new LinkedHashSet<>();//no dupl, insertion order
		s.add("hi");
		s.add(12);
		s.add(12);
		s.add("hello");
		System.out.println(s);
		
		s=new TreeSet<>();//no dupl, arranges in asc by default, no other types allowed
		//in j6 null can be added
	//	s.add(null);
		/*s.add(12);
		s.add(12);
		s.add(132);
		s.add(1);
		s.add(123);*/
	/*//	s.add("hello");
		s.add("aLpha");
		s.add("Beta");
		s.add("beta");
		s.add("alpha");
		s.add("Alpha");
		s.add("ALPHA");
		s.add("alphA");*/
	//	s.add(new Admin());
		System.out.println(s);
	}

}