package com.atos.collectiondemo_day3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ListComparable {

	public static void main(String[] args) {
	
		List l=new ArrayList<>();
		l.add(12);
		l.add(1);
		l.add(1);
		l.add(2);
		l.add(33);
		Comparator c=Collections.reverseOrder();
		Collections.sort(l,c);
		System.out.println("for primitives "+l);
		l.add(new Admin(1001, "ajay", 20000));
		l.add(new Admin(1004, "jay", 40000));
		l.add(new Admin(1005, "vijay", 20345));
		l.add(new Admin(1003, "ajeesh", 2400));
		Collections.sort(l);
		for(Object a:l){
			System.out.println(a);
		}
	}

}

class Admin implements Comparable{

	private int id;
	private String name;
	private int sal;
	
	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + ", sal=" + sal + "]";
	}

	public Admin() {
		// TODO Auto-generated constructor stub
	}
	
	public Admin(int id, String name, int sal) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getSal() {
		return sal;
	}


	public void setSal(int sal) {
		this.sal = sal;
	}


	
	@Override
	public int compareTo(Object o) {
		Admin ad =(Admin)o;
		if(this.sal==ad.sal){
			return 0;	
		}
		else if(this.sal>ad.sal){
			return 1;
		}
		else{
			return -1;
		}
		
	}
	/*2400,20000,24434,18000,18000
	
	2400(this),20000 (o)
	2400(this),24434 (o)
	2400(this),18000 (o)*/
	
	
	
	
}