package com.atos.collectiondemo_day4;

import java.util.Stack;

public class TestStack_vector {

	
	public static void main(String ar[]){
		Stack s=new Stack();
		s.push(12);
		s.push(12);
		s.push(121);
		s.push(null);
		s.push(111);
		s.push(124);
		s.push(22);
		System.out.println(s);//filo
		
	//	System.out.println(s.peek());
		System.out.println(s.pop());
		//System.out.println(s.peek());
		System.out.println(s.pop());
		//System.out.println(s.peek());
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.empty());
	}
	
}
