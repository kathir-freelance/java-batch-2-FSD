package com.atos.collectiondemo_day4;

import java.util.ArrayList;
import java.util.List;

public class TestTemplateGnerics {

	public static void main(String[] args) {
		Temp<String> t=new Temp<>();
		System.out.println(t.a);
		System.out.println(t.display());
		t.display("234");
		ArrayList<Integer> aList=new ArrayList<>();//homogenous collections,  type safe
		//aList.add("hi");
		aList.add(12334);
		
		List<Employee> pplList=new ArrayList<>();
		pplList.add(new Employee("rizwan", 1001));
		pplList.add(new Employee("rishi", 1003));
		pplList.add(new Admin());
	//	pplList.add(new vehicle());
		
		
	}

}
class vehicle{}
class Admin extends Employee 
{
	public Admin() {
	super();
	}
	public Admin(String name, int id) {
		super(name, id);
		// TODO Auto-generated constructor stub
	}}
class Employee{
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	String name;
	int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]";
	}
	
	
}
class Temp<T> //T is known only at runtime
{
	T a;
	public T display(){
		return a;
	}
	public void display(T elem){
	System.out.println(elem);
	}
}