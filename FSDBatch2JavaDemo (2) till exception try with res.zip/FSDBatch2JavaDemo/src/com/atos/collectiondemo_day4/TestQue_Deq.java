package com.atos.collectiondemo_day4;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;

public class TestQue_Deq {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Queue q=new PriorityQueue<>();//aranges elements in asc
	
		Queue q=new LinkedList<>();//arranges in insertion ot=rder, FIFo
		q.add(12);
		q.add(134);
		q.add(12);
		q.add(1);
		q.add(45);
		System.out.println(q);
		System.out.println(q.poll());
		System.out.println(q.poll());
		System.out.println(q.poll());
		
		Deque d=new ArrayDeque<>();//Fifo
	/*	d.add("hi");
		d.add("hello");
		d.add("welcome");
		d.add("alex");
		System.out.println(d);
		System.out.println(d.pop());
		System.out.println(d.pop());
		System.out.println(d.pop());
		System.out.println(d.pop());
		System.out.println(d.pop());
		
*/
		
		d.push("welcome");
		d.push("hllo");
		d.push("alpha");
		System.out.println(d);
		
		System.out.println(d.pop());
		System.out.println(d.pop());
		
	}

}
