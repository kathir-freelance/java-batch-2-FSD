package com.atos.collectiondemo_day5;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapDemo2 {

	private static Map<Integer,Product> prodList=null;
	static {
	prodList=new HashMap<>();
	prodList.put(10001,new Product(10001,"tv",23456.6f,4));
	prodList.put(10002,new Product(10002,"smart tv",43534.6f,6));
	prodList.put(10003,new Product(10003,"dvd",5000.53f,6));
	System.out.println(prodList);
	}
	
	public static void main(String[] args) {
//admin part
		do{
		System.out.println("Online Ecommerce site");
		System.out.println("please choose the option");
		System.out.println("1. add product");
		System.out.println("2. delete product");
		System.out.println("3. modify product");
		System.out.println("4. select product by ID");
		System.out.println("5. get All the product");
		System.out.println("6. exit");
		
		Scanner scan=new Scanner(System.in);
		System.out.println("pls choose the option b/w 1-6");
		int option=scan.nextInt();
		switch(option){
		
		case 1: 
			//id to be generated
			System.out.println(Math.random());
			int id=(int) (Math.random()*10000);
			System.out.println("enter name of the product");
			String name=scan.next();
			System.out.println("enter qty of the product");
			int qty=scan.nextInt();
			System.out.println("enter price of the product");
			float price=scan.nextFloat();
			Product p1=new Product(id, name, price, qty);
			int storedId=addProduct(p1);
			System.out.println("product is stored with id :: "+storedId);
			break;
		case 2:
			System.out.println("pls enter id to delete");
			int delId=scan.nextInt();
			int id1=deleteProduct(delId);
			if(id1==0)
				System.out.println("not found!!!");
			else
				
			System.out.println("product with "+id1+" has been deleted");
			
			break;
		case 4:
			System.out.println("pls enter id to search");
			int searchId=scan.nextInt();
			Product p=getProductById(searchId);
			if(p!=null)
			System.out.println(p);
			else
				System.out.println("product is not available with the given id");
			break;
		case 5:
			Map<Integer,Product> pList=getAllProducts();
			 for(Map.Entry me : pList.entrySet())
		        {
		            System.out.println("Key ="+me.getKey()+", Value ="+me.getValue());    
		        }
			break;
		}
		
		}while(true);
		
	}

	private static int deleteProduct(int delId) {
		Product p=prodList.remove(delId);
		int id=0;
		if(p!=null)
			id=p.getpId();
		return id;
	}

	private static Product getProductById(int id) {
		Product obj=prodList.get(id);
		return obj;
		
	}

	private static Map<Integer,Product> getAllProducts() {
		return prodList;
	}

	public static int addProduct(Product p){
		prodList.put(p.getpId(), p);
		System.out.println(prodList);
		return p.getpId();
	}
}
