package com.atos.day1_basics;

public class Human extends Primate{

	public void walk()//overriding or redefining the meth in sub class
	{
		System.out.println("in first line - logic");
		super.walk();
		System.out.println("+ sub class logic ---> 2 legs to walk");
	}
}
