package com.atos.collectiondemo_day6;

public class TryWithRes2 {

	static A nOb=null;
	public static void main(String[] args) {
	
		try(A ob=new A();B obj=new B();C o=new C();){
			nOb=ob;
			System.out.println("in try");
		}
		catch(Exception e){
			System.out.println("exception occured");
		}
		
	}

}

class A implements AutoCloseable
{
	public A() {
		System.out.println("obj A is created");
		}
			
	@Override
	public void close() throws Exception {
	
		System.out.println("obj a is closed");
		
	}
	
}
class B implements AutoCloseable{
public B() {
System.out.println("obj b is created");
}
	
	@Override
	public void close() throws Exception {
	//	System.out.println("object of B closed");
		throw new Exception();
	}
	
}
class C extends B{
	public C() {
	System.out.println("obj c created");
	}
}
