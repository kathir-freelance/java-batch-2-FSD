package com.atos.collectiondemo_day6;

public class ExcepDemo2 {

	public static void main(String[] args) {
		System.out.println("in main");
		try {
			new ExcepDemo2().method1();
		} catch (Exception e) {
			System.out.println("in excep");
			System.out.println(e.getMessage());
		}
		
	}
	public void method1() throws Exception{
		System.out.println("in m1");
		method2();
		
	}
	public void method2() throws Exception{
		System.out.println("in m2");
		method3();
		
	}
	public void method3() throws Exception{
		System.out.println("in m3");
		method4();
		
	}
	public void method4() throws Exception
	{
		System.out.println("in m4");
		if(90>8)
		{
			throw new Exception();
		}
		
	}
}

