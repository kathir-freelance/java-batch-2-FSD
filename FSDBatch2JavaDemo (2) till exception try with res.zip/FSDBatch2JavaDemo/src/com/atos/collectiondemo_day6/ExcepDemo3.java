package com.atos.collectiondemo_day6;

public class ExcepDemo3 {

	public static void main(String[] args) {
/*
			float a=1.0f/0.0f;
			System.out.println(a);
			float b=0.0f/0.0f;
			System.out.println(b);
			float c=-1.0f/0.0f;
			System.out.println(c);*/
		
		//multi catc block - j7 
		try{
			String s=null;
			s.concat("hi");
			int a=9/0;
		}
		catch(NullPointerException | ArithmeticException e)
		{
			System.out.println("pls contact admin");
		}
		catch(Exception e){
			System.out.println("excep occured");
		}
	}

}
