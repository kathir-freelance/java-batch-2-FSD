package com.atos.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/valid.do")
public class ValidateController extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("inget");
		doPost(req, resp);
	}
	PrintWriter pw=null;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	pw=resp.getWriter();
	pw.print("<html>");
		//logic
		System.out.println("in post");
		String n=req.getParameter("number");
		int numb=Integer.parseInt(n);
		System.out.println(numb);
		
		String msg=null;
		RequestDispatcher rd=null;
		
		String target="output.view";
		if(numb<0)
		{
			msg="<h1>"+numb+" is negative</h1>";

		//	System.out.println(numb+" is negative");
		}
		else{
		//	System.out.println(numb+"is positive");
			msg="<h1>"+numb+" is positive</h1>";
		}

		rd=req.getRequestDispatcher(target);//gets the page address
		req.setAttribute("key", msg);
		rd.forward(req, resp);
	}
	
}