package com.atos.viewserv;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/output.view")
public class outputServ extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	PrintWriter pw=null;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Object o=req.getAttribute("key");
		//String  o=(String)req.getAttribute("key");
		pw=resp.getWriter();
		pw.print("<html>");
		pw.print("<body>");
		pw.println(o);		
		pw.print("</body>");
		pw.print("</html>");
		
		
	}
}