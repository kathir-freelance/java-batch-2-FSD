package com.atos.day1_basics;

public class TestPoly {

	public static void main(String[] args) {
		
		User u=null;
		u=new PaidUser();
	//	u=new GuestUser();
		u.login();
		if(u instanceof PaidUser){
		PaidUser p1=(PaidUser)u;
		p1.offlineDownload();
		}
		else if(u instanceof GuestUser){
			GuestUser g1=(GuestUser)u;
			g1.registerAsPaid();
			
		}
	//	u=new GuestUser();
//		u.login();
		
	}

}
