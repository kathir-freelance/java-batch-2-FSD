package com.atos.collectiondemo_day3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class CollectionDemo {

	public static void main(String[] args) {
		
		List l=new ArrayList();//random access , freq if u r searching for data
		l=new LinkedList();//inserting or deleting 
	//	List l1=new ArrayList<>();
		l.add(110);//implicit conversion - auto boxing - converting or wrapping a valuetype 
		//into obj type
		l.add(110);
		l.add(null);
		l.add(null);
		l.add('c');
		l.add(1);
		l.add("hello");
		l.add("110");
		l.add(67.879f);
		l.add(new Integer(89));
		//explicit conversion - dev does
		// uses wrapper classes  //called as boxing		
		System.out.println(l);
		
		// access elemnts by using insex value
		System.out.println(l.get(6));
		
		l.add(6, "six");
		System.out.println("after adding elem in 6 "+l);
		System.out.println(l.get(6));
		
		l.set(6,"my data");
		System.out.println(l);
		
		l.remove(6);
		System.out.println("after remv "+l);
//		l.remove(index)
		
		Integer i=90; // auto boxing
		System.out.println(i);// auto unboxing
		System.out.println(i.intValue());//unboxing
		// 9 wrapper classesc avbl
		//9 wrapper classes avbl, each matches to datatypes
		
		System.out.println(l.size());
		
		//if(l.size()==0)
	//	System.out.println(l.isEmpty());
	//	l.clear();
		System.out.println(l);
		System.out.println(l.isEmpty());
/*		Iterator ob1=l.iterator();//moves only in forward direction
		//it dynamically removes the data
		while(ob1.hasNext())
		{
			System.out.println(ob1);
			Object o=ob1.next();
			if(o.equals(new Integer(89)))
				ob1.remove();
		}
		System.out.println(l);
		System.out.println(l.isEmpty());
			
	}
*/
		ListIterator li=l.listIterator();
		while(li.hasNext())
		{
			System.out.println(li.next());
		//	li.previous();
					
		}
	}
}