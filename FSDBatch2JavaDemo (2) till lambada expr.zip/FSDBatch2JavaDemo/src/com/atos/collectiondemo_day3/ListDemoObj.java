package com.atos.collectiondemo_day3;

import java.util.ArrayList;
import java.util.List;

public class ListDemoObj {
	public static void main(String[] args) {
		//id is auto gen
		//get user
		Employee e=new Employee("ajay",122);
		Employee e1=new Employee("vinoth",124);
		
		List l=new ArrayList<>();
		l.add(e);
		l.add(e1);
		System.out.println(l);
		l.add(23);
		System.out.println(l);
	}
}

class Employee{
	
	String name;
	int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]";
	}
	
	
}
