package com.atos.day2_abstraction;

public class NIIT implements IContract2 {

	int balance=0;

	@Override
	public void trainingJava() {
	System.out.println("training starts");
	System.out.println("test after every 5 days fr 30min");
	balance=IContract.NO_OF_DAYS-20;
	}

	@Override
	public void trainingJsp() {
	System.out.println("niit - jsp training over");	
	}

	@Override
	public void trainingSpring() {
		System.out.println("spring training done");
		
	}
}
