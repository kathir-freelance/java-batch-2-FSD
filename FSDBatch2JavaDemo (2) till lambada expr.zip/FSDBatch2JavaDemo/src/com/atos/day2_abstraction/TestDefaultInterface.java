package com.atos.day2_abstraction;

public class TestDefaultInterface {

	public static void main(String[] args) {
	
		DefaultInterface d=null;
		d=new R();
		d.meth();
		DefaultInterface.meth1();
		//d.meth1();
	}

}
class R implements DefaultInterface{
	
	@Override
	public void meth() {
		// TODO Auto-generated method stub
		DefaultInterface.super.meth();
		
	}
}