package com.atos.day2_abstraction;

public interface DefaultInterface {

	default void meth(){
		System.out.println("in default");
	}
	static void meth1(){
		System.out.println("in static");
	}

}


//marker interface - type checking 
//serializable

// one abstract meth - functional interface (in j8)



