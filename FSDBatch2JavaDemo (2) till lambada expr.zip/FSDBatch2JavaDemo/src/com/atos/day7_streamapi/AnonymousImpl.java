package com.atos.day7_streamapi;

public class AnonymousImpl {

	public static void main(String[] args) {
		IPayment i=new IPayment() {
			
			@Override
			public void pay(int amt) {
System.out.println("hi");				
			}
		};
		i.pay(900);
	}

}
