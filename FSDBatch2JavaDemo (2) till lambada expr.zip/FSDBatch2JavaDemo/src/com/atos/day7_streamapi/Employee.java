package com.atos.day7_streamapi;

public class Employee {

}
