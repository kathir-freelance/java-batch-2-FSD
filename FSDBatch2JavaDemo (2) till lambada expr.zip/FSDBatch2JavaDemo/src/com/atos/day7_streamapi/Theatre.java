package com.atos.day7_streamapi;

public class Theatre implements IPayment{

		@Override
	public void pay(int amt) {
		System.out.println("amt is payed thru online upi");
		
	}

}
