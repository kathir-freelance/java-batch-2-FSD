package com.atos.day7_streamapi;

public interface IEmployeeSupply {

	public abstract Employee getEmp();
}
