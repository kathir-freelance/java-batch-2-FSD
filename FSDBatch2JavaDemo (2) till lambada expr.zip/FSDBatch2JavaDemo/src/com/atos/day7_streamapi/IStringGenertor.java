package com.atos.day7_streamapi;

public interface IStringGenertor {

	public abstract String generate();
}
