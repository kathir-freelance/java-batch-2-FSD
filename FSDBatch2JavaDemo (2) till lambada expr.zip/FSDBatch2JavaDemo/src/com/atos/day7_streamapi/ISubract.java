package com.atos.day7_streamapi;

public interface ISubract {
	public abstract int sub(int a,int b);
}
