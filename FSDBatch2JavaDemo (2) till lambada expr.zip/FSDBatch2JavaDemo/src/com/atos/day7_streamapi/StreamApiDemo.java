package com.atos.day7_streamapi;

public class StreamApiDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
