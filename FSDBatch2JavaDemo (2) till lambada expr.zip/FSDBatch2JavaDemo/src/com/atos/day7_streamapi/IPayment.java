package com.atos.day7_streamapi;

public interface IPayment {
	public abstract void pay(int amt);
}
