package com.atos.day7_streamapi;

import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class LambadaImpl {

	public static void main(String[] args) {
		
		IPayment ip=(int amt)-> System.out.println("amt is "+amt);
		ip.pay(9000);
		
		IPayment ip1=(int amt)-> {
			amt=amt-500;
			System.out.println("discount amt is 500");
			System.out.println("amt payable "+amt);
		};
		ip1.pay(7700);
		
		//public abstract int sub(int a,int b);
		ISubract sub=(int a,int b)-> a-b;
		int res=sub.sub(89, 9);
		System.out.println(res);
		
		ISubract sub1=(int a,int b)-> {
			int result=0;
			a=a*2;
			b=b-2;
			result=a-b;
			return result;
		};
		int r=sub1.sub(6,3);
		System.out.println(r);
	
		IStringGenertor str=()-> "hi";
		System.out.println(str.generate());
		System.out.println(str.generate());
	
		sub1=(d,e)-> d-e;
		res=sub1.sub(67,90);
		System.out.println(res);
		
		//predefined fn interfaces
		
		/*Supplier ---- no input but o/p ll be given
		 * 	IntSupplier
		Consumer----- takes input, but no output return
			BiConsumer - takes 2 i/ps but no return 
		Predicate -- can take 1 arg but return true or false
		  	BiPredicate - can take 2 arg and return true or false
		  Function - can take 1 arg return any value 
			BiFunction - can take 2 arg return one value of any type
		*/
		IEmployeeSupply is=()-> new Employee();
		Employee e=is.getEmp();
		System.out.println(e);
		
		// or
		
		Supplier<Employee> sup=()->new Employee();
		e=sup.get();
		System.out.println(e);
		
		IntSupplier intsup=()->(int)Math.random()*1000;
		int d=intsup.getAsInt();
		System.out.println(d);
		
		Consumer cc=(amt)->System.out.println(amt);
		cc.accept(1000);
		
		//public boolean login(String name,String pass);
		ILoginValidator iv=(n,p)->{
			boolean stat=n.equals("admin") && p.equals("admin")?true:false;
			return stat;
		};
		System.out.println(iv.login("admin","admin"));
		
		BiPredicate p=(name,pass)->{
			boolean stat=name.equals("admin") && pass.equals("admin")?true:false;
			return stat;
		};
		System.out.println(p.test("admin","admin"));
		
	}
	
	

}
