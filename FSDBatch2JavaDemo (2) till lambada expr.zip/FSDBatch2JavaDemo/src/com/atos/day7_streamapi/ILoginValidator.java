package com.atos.day7_streamapi;

public interface ILoginValidator {

public boolean login(String name,String pass);
	
	
}