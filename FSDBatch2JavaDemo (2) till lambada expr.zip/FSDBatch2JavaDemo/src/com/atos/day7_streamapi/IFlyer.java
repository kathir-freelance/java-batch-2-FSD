package com.atos.day7_streamapi;

@FunctionalInterface//j8
public interface IFlyer {
	//public abstract void fly1();
	//- how to avoid this 
	//being added into any thing u decided as functinal interface
	public abstract void fly();
	
	//u can hv any number of default & static methods
	public default String getData(){
	return "hello";	
	}
}
