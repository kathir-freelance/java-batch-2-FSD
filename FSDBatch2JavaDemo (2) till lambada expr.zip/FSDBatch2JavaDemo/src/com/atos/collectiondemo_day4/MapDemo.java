package com.atos.collectiondemo_day4;

import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		
	//	Map<Integer,String> m=new HashMap();
		Map<Integer,String> m=new Hashtable();
		m.put(1001, "hello");
		m.put(1001, "hello");
		m.put(1001, "duplicate in key");
		m.put(1002, "world");
		m.put(1003, "welcome");
	//	m.put('y', "alphabet");
	//	m.put(10.5f, 10);
		//m.put(null, null);4
		//m.put(78, null);//cant add null key or value in hashtable
		m.put(null, "its null");
	//	m.put("key1", "its null");
		System.out.println(m);
		
		System.out.println(m.get(1001));
		System.out.println(m.get(null));
		Set keys=m.keySet();
		System.out.println(keys);
		Collection val=m.values();
	System.out.println(val);
	
	//covert map to set
	
	Set mapSet=m.entrySet();
	System.out.println(mapSet);
	
/*	for(Object o:m.entrySet()){
		
		System.out.println(o);
	}
*/
/*for(Map.Entry o:m.entrySet()){
		
		System.out.println(o);
	}*/
	
	}

}
