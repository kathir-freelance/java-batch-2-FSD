package com.atos.collectiondemo_day5;

public class Product {

	private int pId;
	private String pName;
	private float price;
	private int qty;
	
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(int pId, String pName, float price, int qty) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.price = price;
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "Product [pId=" + pId + ", pName=" + pName + ", price=" + price + ", qty=" + qty + "]";
	}
	
}
