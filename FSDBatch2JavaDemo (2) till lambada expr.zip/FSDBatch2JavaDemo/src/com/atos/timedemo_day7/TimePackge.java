package com.atos.timedemo_day7;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
public class TimePackge {

	public static void main(String[] args) {

		//Date d=new Date();
		//System.out.println(d);
		
	LocalDate tdy=LocalDate.now();
	System.out.println(tdy);
	
	LocalDate d1=LocalDate.of(2020, 1, 31);
	System.out.println(d1);
	System.out.println(LocalDate.MAX);
	System.out.println(LocalDate.MIN);
	d1=d1.plusDays(12);
	
	System.out.println("plus 12 days : "+d1);
	LocalDateTime dt=LocalDateTime.now();
	System.out.println(dt);
	ZonedDateTime zd=ZonedDateTime.now();
	System.out.println(zd);
	System.out.println(zd.getZone());
	System.out.println(zd.getOffset());
	LocalDate previousMonthSameDay = LocalDate.now().minus(1, ChronoUnit.YEARS);
	System.out.println(previousMonthSameDay);
	
	boolean isAfter = LocalDate.parse("2016-06-02")
			  .isBefore(LocalDate.parse("2016-06-11"));
	
	System.out.println(isAfter);
	
	ZoneId zoneId = ZoneId.of("Pacific/Guadalcanal");
	ZonedDateTime d2=ZonedDateTime.of(LocalDateTime.now(), zoneId);
	System.out.println(d2);
	
	Instant i=Instant.now();
	System.out.println(i);
	}

}
