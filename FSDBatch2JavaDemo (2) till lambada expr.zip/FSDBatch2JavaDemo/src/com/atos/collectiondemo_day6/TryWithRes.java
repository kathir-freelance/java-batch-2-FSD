package com.atos.collectiondemo_day6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TryWithRes {

	public static void main(String[] args) {
	
		//create, open & close resource - we get excep
		// we may forget to close the res
		//coz of excep the code for closing might not have executed
		
		try (FileWriter fw=new FileWriter("a.txt")){
			fw.write(" hello world");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("file is missing "+e.getMessage());
		} catch (IOException e) {
			System.out.println("unable to write");
		}

	}

}
