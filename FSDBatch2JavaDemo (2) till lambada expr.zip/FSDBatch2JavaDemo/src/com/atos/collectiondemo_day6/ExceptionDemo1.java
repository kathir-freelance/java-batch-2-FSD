package com.atos.collectiondemo_day6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionDemo1 {

	public static void main(String[] args) {
		FileReader fr=null;
		BufferedReader br=null;
		try {
			fr=new FileReader("a.txt");
			br=new BufferedReader(fr);
			String line=br.readLine();
			System.out.println(line);
		} catch (FileNotFoundException e) {
			System.out.println("file is missing");
		} catch (IOException e) {
			System.out.println("unable to read");
		}
		catch(Exception e){
			
		}
		finally{
			System.out.println("executed ");
			try {
				if(br!=null && fr !=null){
				br.close();
				fr.close();
				}
			} catch (IOException e) {
				
			System.out.println("br and fr is closed ");
			
			}
			
		}
		
	}

}
