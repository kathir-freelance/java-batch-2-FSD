package com.atos.collectiondemo_day6;

import java.util.Scanner;
//client
public class CustomeExceptionDemo {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		
		int amt=scan.nextInt();
		try {
		boolean s=	new service().withdraw(amt);
		if(s){
			System.out.println("amy with drawn");
		}
		} catch (MoneyLessException e) {
			System.out.println(e.getMessage());
		}
	}

}
///s2
class service{
	
	public boolean withdraw(int amt) throws MoneyLessException{
		int balance=500;
		boolean status=false;
		if(amt>balance){
			throw new MoneyLessException("cannot with draw");
		//	System.out.println("cannot with draw");
		}
		else{
			status=true;
		//	System.out.println("amt is taken");
		}
		return status;
	}
}

//create a class
//what type of exception u need
// checked or unchecked?
//checked - extends from Exception
//unchecked - extends RuntimeException
//how mny constructor u need to create obj

class MoneyLessException extends Exception
{
	public MoneyLessException() {
		super();
	}
	public MoneyLessException(String msg) {
		super(msg);
		//super();
	}
	
}